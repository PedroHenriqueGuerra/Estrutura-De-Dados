//Exercício 1: CONCEITOS INICIAIS

//Questão 1: Media de Pedro: 92.000000
	   //Media de Maria: 90.000000

//Questão 2: As notas de Maria passa a ser iguais a de Pedro

//Questão 3: Ele libera a memória alocada para o uso da estrutura "aluno",Não.

//Questão 4: 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{
  int idade;
  char nome[50];
  int *notas;
} aluno;

int main(void) {
  aluno a1, a2;
  a1.idade = 10;
  strcpy(a1.nome, "Pedro");
  a2.idade = 12;
  strcpy(a2.nome, "Maria");

  a1.notas = (int*)malloc(5*sizeof(int));
  a2.notas = (int*)malloc(4*sizeof(int));

  int i;
  for(i = 0; i < 5; i++){
    a1.notas[i] = 100;
  }
  for(i = 0; i < 4; i++){
    a2.notas[i] = a1.notas[i];
  }
  for(i = 0; i < 4; i++){
    a2.notas[i] -= 10;
  }
  double media = 0;
  for(i = 0; i < 5; i++){
    media += a1.notas[i];
  }
  media = media / 5;
  printf("Media de %s: %lf\n",a1.nome,media);

  media = 0;
  for(i = 0; i < 4; i++){
    media += a2.notas[i];
  }
  media = media / 4;
  printf("Media de %s: %lf\n",a2.nome,media);

  free(a1.notas);
  free(a2.notas);
  return 0;
}
