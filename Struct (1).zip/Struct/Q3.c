#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

typedef struct{
  double x,y;
} Ponto;

typedef struct{
  double a,b,c;
  // Reta -> ax + by + c = 0
} Reta;

double dista(Ponto p, Ponto q){
  double dist;
  dist = sqrt(pow(p.x - q.x,2) + pow(p.y - q.y,2));
  return dist;
}

int vr(Ponto p, Reta r){
  return (r.a*p.x + r.b*p.y + r.c == 0);
}


int main(void) {
  
}