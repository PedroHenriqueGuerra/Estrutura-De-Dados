#include <stdio.h>
#include <stdlib.h>


typedef struct node {
  int data;
  struct node *next;
}node;

typedef struct node node;

typedef struct {
  node *begin;
} list;

list *createList(){
  list *novo = (list*)malloc(sizeof(list));
  novo->begin = NULL;
  return novo;
}

void add(list *l, int v){
  node *novo = (node*)malloc(sizeof(node));
  novo->data = v;
  novo->next = l->begin;
  l->begin = novo;
}

void printList(list *l){
  node *p = l->begin;
  while(p != NULL){
    printf("%d ", p->data);
    p = p->next;
  }
}

int isEmpty(list *l){
  if (l->begin == 0){
    return 1;
  }
  else return 0;
}

void removeBack(list *l){
  node *pAux,*pAnt = NULL;
  pAux = l->begin;
  while(pAux->next !=NULL){
  pAnt = pAux;
  pAux = pAux->next;
  }

  if(pAnt == NULL){
  l->begin = pAux->next;
  free(pAux);
  }

  else{
  pAnt->next = pAux->next;
  free(pAux); 
  }
}

int size(list *l){
  node*p = l->begin;
  int cont = 0;
  while(p!=NULL){
    cont += 1;
    p = p->next;
  }
  return cont;
}

//SEGUNDA QUESTÃO - OPERAÇÕES ESPECIAIS//

int hasElement(list *l, int v){
  node *p = l->begin;
  int cont = 0;
  while(p!=NULL){
    if(p->data == v){
      return cont;
    }
    else{
      cont++;
      p = p->next;
    }
  }
  return -1;
}

int insertPosition(list *l, int v, int pos){
  int cont = 0;
  node *p = l->begin;
  if(pos >= 0 && pos < size(l)){
    while(cont != pos){
      p = p->next;
      cont++;
    }
    p->data = v;
  }
  else{
    return -1;
  }
return 0;
}


int removePosition(list *l, int pos){
  node *p;
  p = l->begin;
  int i = 0;
  if(pos >= 0 && pos < size(l)){
    if(pos == 0){
      l->begin = p->next;
    }
    else if(p != NULL){
      for(i = 0; i < pos-1; i++){
        p = p->next;
      }
      p->next = p->next->next;
    }
  }
  else{
    return -1;
  }
  return 0;
}

int removeElement(list *l, int v){
  node*p;
  p = l->begin;
  int cont = 0,i = 0;
  while(cont < size(l)){
    if(cont == 0 && p->data == v){
      l->begin = p->next;
      return cont;
    }
    else if(p->data == v){
      p = p->next;
      return cont;
    }
    else{
      cont++;
      p = p->next;
    }
  }
  return -1;
}

int get(list *l, int pos, int *vret){
  if(pos < size(l)){
    node*p = l->begin;
    int cont = 0;
    while(cont<=pos){
      *vret = p->data;
      p = p->next;
      cont += 1;
    }
    return 0;
  }
  return -1;
}

int main(void) {
  list *l;
  l = createList();
  add(l,5);
  add(l,10);
  add(l,20);
  add(l,40);
  add(l,80);
  removeBack(l);
  insertPosition(l,10,4);
  removePosition(l,3);
  printf("%d\n",removeElement(l,80));
  printf("%d\n",hasElement(l,5));
  printf("%d\n",size(l));
  printList(l);  
  return 0;
}