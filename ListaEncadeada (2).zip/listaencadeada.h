typedef struct node {
  int v;
  struct node *next;
}node;

typedef struct node node;

typedef struct {
  node *begin;
}list;

list *createList();

void add(list *l, int v);

void printList(list *l);

int isEmpty(list *l);

void removeBack(list *l);

int size(list *l);


//SEGUNDA QUESTÃO - OPERAÇÕES ESPECIAIS//


int hasElement(list *l, int v);

int insertPosition(list *l, int v, int pos);

int removePosition(list *l, int pos);

int removeElement(list *l, int v);

int get(list *l, int pos, int *vret);