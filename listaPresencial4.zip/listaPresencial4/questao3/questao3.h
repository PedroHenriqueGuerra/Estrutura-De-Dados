/*
Para essa solução eu pensei em já declarar uma variável quantEle na struct e, cada vez que fosse criado
ou removido algum valor então atualizariamos essa variável, semelhante aos algoritmos de lista dinâmica 
vistos no slide de lista estática.
 */

#include <stdlib.h>

struct node{
    int data;
    struct node *next;
};
typedef struct node node;

typedef struct{
    struct node *begin;
    int quantEle;
}list;

//Questão 1
list *createList();
void add(list *l,int v);
void printList(list *l);
int isEmpty(list *l);
void removeBack(list *l);
int size(list *l);

//Questão 2
int hasElement(list *l,int v);
int insertPosition(list *l,int v,int pos);
int removePosition(list *l,int pos);
int removeElement(list *l,int v);
int get(list *l,int pos,int *vret);