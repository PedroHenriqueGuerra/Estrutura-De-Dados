#include <stdlib.h>
#include <stdio.h>
#include "questao3.h"

//-----------------QUESTÃO 1-----------------//
list *createList(){
    list *nova = (list*)malloc(sizeof(list));
    nova->begin = NULL;
    //Definimos a quantidade de elementos
    nova->quantEle = 0;
    return nova;
}

void add(list *l,int v){
    node *novo = (node*)malloc(sizeof(node));
    novo->data = v;
    node *pAux = l->begin;
    node *pAnt = NULL;
    while(pAux != NULL){
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAnt == NULL){
        novo->next = NULL;
        l->begin = novo;
    }else{
        novo->next = pAux;
        pAnt->next = novo;
    }
    //Aumentamos a quantidade de elementos
    l->quantEle++;
}

void removeBack(list *l){
    node *pAux,*pAnt = NULL;
    pAux = l->begin;
    while(pAux->next != NULL){
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAnt == NULL){
        l->begin = pAux->next;
        free(pAux);
    }
    else{
        pAnt->next = pAux->next;
        free(pAux);        
    }
    l->quantEle--;
}

void printList(list *l){
    node *pAux = l->begin;
    printf("[ ");
    while (pAux != NULL){
        printf("%d ",pAux->data);
        pAux = pAux->next;
    }
    printf("]\n");
}

int isEmpty(list *l){
    if(l->begin != NULL){
        return 0;
    }else{
        return 1;
    }
}

int size(list *l){
    return l->quantEle;
}

//-----------------QUESTÃO 2-----------------//

int hasElement(list *l,int v){
    node *pAux = l->begin;
    int cont = 0;
    while (pAux != NULL && pAux->data != v){
        cont++;
        pAux = pAux->next;
    }
    if(pAux != NULL){
        return cont;
    }else{
        return -1;
    }
}

int insertPosition(list *l,int v,int pos){
    node *pAux,*pAnt = NULL;
    node *novo  = (node*)malloc(sizeof(node));
    novo->data = v;
    pAux = l->begin;
    int tam = size(l);
    if(pos > tam || pos < 0){
        return -1;
    } else{
        int i = 0;
        if(pos == 0){
            novo->next = pAux;
            l->begin = novo;
            l->quantEle++;
            return 0;
        } else{
            for(i;i != pos;i++){
                pAnt = pAux;
                pAux = pAux->next;
            }
            pAnt->next = novo;
            novo->next = pAux;
            l->quantEle++;
            return 0;
        }
    }
}

int removePosition(list *l,int pos){
    node *pAux,*pAnt = NULL;
    pAux = l->begin;
    int tam = size(l)-1;
    if(pos > tam || pos < 0){
        return -1;
    } else{
        int i = 0;
        if(pos == 0){
            l->begin = l->begin->next;
            free(pAux);
            l->quantEle--;
            return 0;
        } else{
            for(i;i != pos;i++){
                pAnt = pAux;
                pAux = pAux->next;
            }
            pAnt->next = pAux->next;
            free(pAux);
            l->quantEle--;
            return 0;
        }
    }
}

int removeElement(list *l,int v){
    node *pAnt;
    node *pAux = l->begin;
    int cont = 0;
    while (pAux != NULL && pAux->data != v){
        cont++;
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAux != NULL){
        if(cont == 0){
            l->begin = l->begin->next;
            free(pAux);
            l->quantEle--;
            return cont;
        } else{
            pAnt->next = pAux->next;
            free(pAux);
            l->quantEle--;
            return cont;
        }
    }else{
        return -1;
    }
}

int get(list *l,int pos,int *vret){
    if(pos > size(l) || pos < 0){
        return -1;
    } 
    else{
        node *novo = l->begin;
        int i;
        for(i = 0; i < pos; i++)
            novo = novo->next;
        *vret = novo->data;
        return 0;
    }
}