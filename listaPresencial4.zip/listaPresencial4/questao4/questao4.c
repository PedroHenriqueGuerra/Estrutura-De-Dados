#include "questao4.h"   

//Criamos os atributos que apontam pra o inicio e pra o fim da lista
list *criaLista(){
    list *l = (list*)malloc(sizeof(list));
    l->begin = NULL;
    l->end = NULL;
    return l;
}

void insereInicio(list *l, int v){
    node *novo = (node*)malloc(sizeof(node));
    novo->data = v;
    //O anterior do novo valor recebe NULO
    //O próximo dele recebe o Begin (por que ele vai ser o novo início agora)
    novo->before = NULL;
    novo->next = l->begin;
    /*Se o inicio for nulo, quer dizer que não havia valor antes, logo
    o begin vai ser o próprio novo valor e, como ele é o único, será o fim também
    Senão bixo, quer dizer que tem valor. Com isso, dizemos que o anterior do antigo
    begin vai apontar pro novo, isso pelo fato do novo begin ser o novo*/
    if(l->begin == NULL){
        l->begin = novo;
        l->end = novo;
    } else{
        l->begin->before = novo;
        l->begin = novo;
    }
}

void insereFim(list *l,int v){
    node *novo = (node*)malloc(sizeof(node));
    novo->data = v;
    //Como ele é o último, então ele é o END, logo ele aponta pra NULL
    novo->next = NULL;
    //Ele vai apontar agora pra o antigo valor END
    novo->before = l->end;
    /*Se o inicial for NULO, quer dizer que não havia valor na lista. Com isso
    o início e fim apontam pra o novo.
    Senão bixo, o antigo END aponta pra o novo valor e o END vira esse novo valor*/
    if(l->begin == NULL){
        l->begin = novo;
        l->end = novo;
    } else{
        l->end->next = novo;
        l->end = novo;
    }
}

node *busca(list *l,int v){
    node *p = l->begin;
    while (p != NULL){
        if(p->data == v){
            return p;
        } 
        p = p->next;
    }
    
}

void removeValor(list *l,int v){
    //Primeiro a gente busca o valor, pra saber se ele tá na lista
    node *p = busca(l,v);
    if(p != NULL){
        //Caso esteja a gente tem 4 casos pra entender
        //Se o valor de início e de fim forem iguais, significa que só há um valor na lista
            //Com isso a gente faz esse início e fim apontarem pra o NULL;
        //Se o valor encontrado na busca for iguai ao inicio
            //Dizemos que o inicio tem que receber o próximo desse valor
            //E que a referência do valor anterior tem que ser NULL
        //Se o valor encontrado na busca for iguai ao fim
            //Dizemos que o fim tem que receber o anterior desse valor
            //E que a referência do valor próximo tem que ser NULL
        //Por fim é o caso geral. Aí você leia e tente entender Hugo.
        if(l->begin == l->end){
            l->begin == NULL;
            l->end == NULL;
        } else if(p == l->begin){
            l->begin = p->next;
            l->begin->before = NULL;
        } else if(p == l->end){
            l->end = p->before;
            l->end->next = NULL;
        } else{
            p->before->next = p->next;
            p->next->before = p->before;
        }
        free(p);
    }
}

void becomeCircular(list *l){
    if(l->begin == NULL && l->end == NULL){
        printf("Nada a se fazer, lista vazia\n");
    } else{
        l->begin->before = l->end;
        l->end->next = l->begin;
    }
}

void printCircular(list *l){
    node *pAux = l->begin;
    printf("[ ");
    if(l->begin != NULL){
        do{
            printf("%d ",pAux->data);
            pAux = pAux->next;
        } while(pAux != l->begin);
        printf("]\n");
    }
}

void insertCircular(list *l,int v){
    node *novo = (node*)malloc(sizeof(node));
    novo->data = v;
    node *pBeg = l->begin;
    node *pEnd = l->end;
    pEnd->next = novo;
    pBeg->before = novo;
    novo->before = pEnd;
    novo->next = pBeg;
}

void removeElementCircular(list *l,int v){
    busca(l,v);
    if(l->begin != NULL){
        node *pAux = l->begin;
        do{
            if(pAux->data == v){
                if(l->begin == l->end){
                    l->begin = l->end = NULL;
                } else{
                    if(pAux == l->begin){
                        l->begin = pAux->next;
                    } else if(pAux == l->end){
                        l->begin->before = l->end->before;
                        l->end->before->next = l->end->next;
                    }
                }
                pAux->before->next = pAux->next;
                pAux->next->before = pAux->before;
                break;
            }
            pAux = pAux->next;
        } while(pAux != l->begin);
        free(pAux);
    }
}