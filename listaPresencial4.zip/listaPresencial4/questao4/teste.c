#include "questao4.c"

int main(void){
    list *l = criaLista();
    insereInicio(l,10);
    insereInicio(l,20);
    insereFim(l,50);
    insereInicio(l,30);
    insereInicio(l,40);
    removeValor(l,20);
    removeValor(l,60);
    printf("Pós circular\n");
    becomeCircular(l);
    printCircular(l);
    insertCircular(l,60);
    printCircular(l);
    removeElementCircular(l,60);
    printCircular(l);
    removeElementCircular(l,30);
    printCircular(l);
    removeElementCircular(l,40);
    printCircular(l);
}