#include <stdlib.h>
#include <stdio.h>
#include "listaEncadeada.h"

//-----------------QUESTÃO 1-----------------//

/*
    -Primeiro se cria dinamicamente o nodo;
    -Se define o valor inicial como nulo;
    -Retornamos o nodo criado.
*/
list *createList(){
    list *nova = (list*)malloc(sizeof(list));
    nova->begin = NULL;
    return nova;
}

/*
    -Criamos o nodo;
    -Dizemos que o valor desse nodo recebe o valor passado;
    -Dizemos que o próximo vai apontar para onde o begin tava apontando;
    -Por fim dizemos que o begin agora aponta para o novo.

*/
void add(list *l,int v){
    node *novo = (node*)malloc(sizeof(node));
    novo->data = v;
    node *pAux = l->begin;
    node *pAnt = NULL;
    while(pAux != NULL){
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAnt == NULL){
        novo->next = NULL;
        l->begin = novo;
    }else{
        novo->next = pAux;
        pAnt->next = novo;
    }

}

/*
    -Primeiro criamos dois ponteiros:
        1º é o que busca o valor em si;
        2º é o que pega o valor do anterior pra não perder a referência.
    -Depois nós criamos um laço de repetição:
        -Nesse laço a gente roda enquanto o ponteiro de busca não for nulo (ou seja, tiver algum valor);
        -E enquanto o próximo não for nulo:
            -Sendo assim dizemos que o ponteiro do valor anterior pega o atual 
            para o atual pegar o próximo e reiniciar a verficação.
    -Pós fim do laço a gente verifica se foi encontrado o último valor:
        -Se for encontrado e o valor anterior for nulo, quer dizer que o valor é o inicial;
            -Com isso nós dizemos que o begin vai apontar pro próximo valor do que será removido.
        -Se for encontrado em qualquer outra posição basra dizer que:
            -O próximo valor do anterior vai receber o próximo do atual.
*/

void removeBack(list *l){
    node *pAux,*pAnt = NULL;
    pAux = l->begin;
    while(pAux->next != NULL){
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAnt == NULL){
        l->begin = pAux->next;
        free(pAux);
    }
    else{
        pAnt->next = pAux->next;
        free(pAux);        
    }
}

//Nem precisa de explicação esses próximos 3
void printList(list *l){
    node *pAux = l->begin;
    printf("[ ");
    while (pAux != NULL){
        printf("%d ",pAux->data);
        pAux = pAux->next;
    }
    printf("]\n");
}

int isEmpty(list *l){
    if(l->begin != NULL){
        return 0;
    }else{
        return 1;
    }
}

int size(list *l){
    node *pAux = l->begin;
    int cont = 0;
    while (pAux != NULL){
        cont++;
        pAux = pAux->next;
    }
    return cont;
}

//-----------------QUESTÃO 2-----------------//

int hasElement(list *l,int v){
    node *pAux = l->begin;
    int cont = 0;
    while (pAux != NULL && pAux->data != v){
        cont++;
        pAux = pAux->next;
    }
    if(pAux != NULL){
        return cont;
    }else{
        return -1;
    }
}

int insertPosition(list *l,int v,int pos){
    node *pAux,*pAnt = NULL;
    node *novo  = (node*)malloc(sizeof(node));
    novo->data = v;
    pAux = l->begin;
    int tam = size(l);
    if(pos > tam || pos < 0){
        return -1;
    } else{
        int i = 0;
        if(pos == 0){
            novo->next = pAux;
            l->begin = novo;
            return 0;
        } else{
            for(i;i != pos;i++){
                pAnt = pAux;
                pAux = pAux->next;
            }
            pAnt->next = novo;
            novo->next = pAux;
            return 0;
        }
    }
}

int removePosition(list *l,int pos){
    node *pAux,*pAnt = NULL;
    pAux = l->begin;
    int tam = size(l)-1;
    if(pos > tam || pos < 0){
        return -1;
    } else{
        int i = 0;
        if(pos == 0){
            l->begin = l->begin->next;
            free(pAux);
            return 0;
        } else{
            for(i;i != pos;i++){
                pAnt = pAux;
                pAux = pAux->next;
            }
            pAnt->next = pAux->next;
            free(pAux);
            return 0;
        }
    }
}

int removeElement(list *l,int v){
    node *pAnt;
    node *pAux = l->begin;
    int cont = 0;
    while (pAux != NULL && pAux->data != v){
        cont++;
        pAnt = pAux;
        pAux = pAux->next;
    }
    if(pAux != NULL){
        if(cont == 0){
            l->begin = l->begin->next;
            free(pAux);
            return cont;
        } else{
            pAnt->next = pAux->next;
            free(pAux);
            return cont;
        }
    }else{
        return -1;
    }
}

int get(list *l,int pos,int *vret){
    if(pos > size(l) || pos < 0){
        return -1;
    } 
    else{
        node *novo = l->begin;
        int i;
        for(i = 0; i < pos; i++)
            novo = novo->next;
        *vret = novo->data;
        return 0;
    }
}