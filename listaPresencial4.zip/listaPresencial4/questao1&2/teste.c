#include "listaEncadeada.c"

int main(void){
    //Teste da questão 1
    printf("-----------Questão 1------------\n");
    list *l = createList();
    add(l,10);
    add(l,20);
    add(l,30);
    add(l,40);
    add(l,50);
    printf("Tamanho: %d\n",size(l));
    printList(l);
    removeBack(l);
    removeBack(l);
    printf("Tamanho: %d\n",size(l));
    printList(l);
    removeBack(l);
    removeBack(l);
    removeBack(l);
    if(isEmpty(l) == 1){
        printf("Lista vazia\n");
    } else{
        printf("Lista com elementos\n");
    }
    printf("-----------Questão 2------------\n");
    //Questão 2
    list *l2 = createList();
    add(l2,10);
    add(l2,20);
    add(l2,40);
    add(l2,80);
    printList(l2);
    int testHas = hasElement(l2,10);
    printf("Nesse teste o elemento 10 existe na posição %d\n",testHas);
    testHas = hasElement(l2,30);
    printf("Nesse teste o elemento 30 não existe.\n");
    insertPosition(l2,30,2);
    printf("Elemento 30 na posição %d\n",hasElement(l2,30));
    printList(l2);
    insertPosition(l2,50,0);
    insertPosition(l2,70,5);
    printList(l2);
    removePosition(l2,0);
    printList(l2);
    removePosition(l2,4);
    printList(l2);
    removePosition(l2,2);
    printList(l2);
    removeElement(l2,20);
    printList(l2);
    removeElement(l2,40);
    printList(l2);
    removeElement(l2,10);
    printList(l2);
    int val;
    get(l2,0,&val);
    printf("Elemento na posição 0 é o %d\n",val);
}