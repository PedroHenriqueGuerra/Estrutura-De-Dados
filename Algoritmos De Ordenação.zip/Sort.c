#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//#define SIZE 1000 //tamanho do vetor

int intcmp(const void *a, const void *b) {
    return *(const int *)a - *(const int *)b;
}

void printArray(int *v, int n) {
    int i = 0;
    for(i = 0; i < n; i++) {
        printf("%d ",v[i]);
    }
    printf("\n");
}

void preencheArray(int *v, int *v2, int *v3,  int *v4, int n) {
    int i = 0;
    for(i = 0; i < n; i++) {
        v[i] = rand()%100; //sorteia valor entre 0 e 99 e atribui ao elemento do vetor
        v2[i] = v[i];
        v3[i] = v[i];
    }
}

int checkSort(int *v, int n) {
    if(n <= 0) return -1;
    int ant = v[0];
    int i;
    for(i = 1; i < n; i++) {
        if(v[i] < ant) return 0;
        ant = v[i];
    }
    return 1;
}

void insertionsort(int array[], int qtd){
	int x;
	for (x = 1; x <= qtd-1; x++){
		int key = array[x];
		int i = x - 1;
		while (i >= 0 && array[i] > key){
			array[i + 1] = array[i];
			i = i - 1;
			array[i + 1] = key;			
		}
	}
}

void merge(int a[], int i, int f){
	int m = (i + f)/2;
	int aux[(f-i+1)];
	int e = i;
	int d = m + 1;
	int k = 0;
	while (e <= m || d <= f){
		if (e > m){
			aux[k++] = a[d++];
		}
		else if (d > f){
			aux[k++] = a[e++];
		}
		else if(a[e] < a[d]){
			aux[k++] = a[e++];
		}
		else{
		aux[k++] = a[d++];
		}
	}
	for(k = i; k <= f; k++){
		a[k] = aux[k-i];
	}
}

void mergeSort(int a[], int i, int f){
	if (f >i ){
		int m = (i + f)/2;
		mergeSort(a, i, m);
		mergeSort(a, m+1, f);
		merge(a, i, f);
	}
}

int partition(int a[],int i,int f){
	int d = i - 1;
	int p = a[f];
	int j, key;
	for(j = i; j <= f-1; j++){
		if (a[j] <= p){
			d = d + 1;
			key = a[j];
			a[j] = a[d];
			a[d] = key;	
		}
	}
	d = d + 1;
	key = a[f];
	a[f] = a[d];
	a[d] = key;
	return d;
}


void quicksort(int a[], int i, int f){
	if (f > i){
		int p = partition(a, i, f);
		quicksort(a, i, p-1);
		quicksort(a, p+1, f);
	}
}

int main() {
    int SIZE;
    
    printf("Informe o tamanho do array:\n");
    scanf("%d",&SIZE);
    
    srand(time(NULL)); //inicializa semente aleatoria
    
    //declara e preenche os arrays de forma aleatória
    int *v = (int*)malloc(SIZE*sizeof(int));
    int *v2 = (int*)malloc(SIZE*sizeof(int));
    int *v3 = (int*)malloc(SIZE*sizeof(int));
    int *v4 = (int*)malloc(SIZE*sizeof(int));
    preencheArray(v,v2,v3,v4,SIZE);
    
    clock_t ticks[2];
    
    ticks[0] = clock();
    mergeSort(v, 0, SIZE-1);
    ticks[1] = clock();
    double tempo1 = (double)(ticks[1] - ticks[0])/ CLOCKS_PER_SEC;   
    printf("Tempo gasto - Merge sort: %lf s.\n", tempo1);
       
    ticks[0] = clock();
    insertionsort(v2, SIZE);
    ticks[1] = clock();
    double tempo2 = (double)(ticks[1] - ticks[0])/ CLOCKS_PER_SEC;
  printf("Tempo gasto - Insertion sort: %lf s.\n", tempo2);
    
    ticks[0] = clock();
    quicksort(v3, 0, SIZE-1);
   //qsort(v3, SIZE, sizeof(int), intcmp);
    ticks[1] = clock();
    double tempo3 = (double)(ticks[1] - ticks[0])/ CLOCKS_PER_SEC;
    printf("Tempo gasto - Quicksort: %lf s.\n", tempo3);
    
    ticks[0] = clock();
    qsort(v4, SIZE, sizeof(int), &intcmp);
    ticks[1] = clock();
    double tempo4 = (double)(ticks[1] - ticks[0])/ CLOCKS_PER_SEC;
    printf("Tempo gasto - Qsort: %lf s.\n", tempo4);
    
    printf("%lf %lf %lf %lf\n",tempo1, tempo2, tempo3, tempo4);

    
    //Verifica se o array final ficou ordenado
    int r = checkSort(v,SIZE);
    printf("Check Merge: %d\n",r);
    r = checkSort(v2,SIZE);
    printf("Check Insertion: %d\n",r);
    r = checkSort(v3,SIZE);
    printf("Check Quick: %d\n",r);
    r = checkSort(v4,SIZE);
    printf("Check Qsort: %d\n",r);
        
    return 0;
}
